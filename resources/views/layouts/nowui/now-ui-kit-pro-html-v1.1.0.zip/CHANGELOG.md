# Change Log

## [1.1.0] 2017-10-24
### Bug Fixing & Bootstrap 4 Beta integration
- Class changes : .card-block to .card-body
- .navbar-toggleable-* to .navbar-expand-*
- .hidden-*-down to .d-none .d-*-block
- .hidden-*-up to .d-*-none
- .checkbox to .form-check
- .radio to .form-check .form-check-radio 
- more class changes here:https://medium.com/@lukaszholeczek/how-to-upgrade-bootstrap-4-alpha-6-to-bootstrap-4-beta-d43b4210f2a3
- Bug fixes for responsive devices
- Small changes for components

## [1.0.1] 2017-08-24
### Minor Fixes
- bug fixes for responsive
- removed isometricGrids.js and modernizr.custom.js library (not used anymore)
- added version in CSS and JS links

## [1.0.0] 2017-08-21
### Original Release
